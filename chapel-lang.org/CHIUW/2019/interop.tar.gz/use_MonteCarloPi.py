import MonteCarloPi

# sets up the Chapel runtime
MonteCarloPi.chpl_setup()

n = 100000
MonteCarloPi.serialVersion(n)
MonteCarloPi.taskParVersion(n)
MonteCarloPi.dataParVersion(n)


# cleans up the Chapel runtime
MonteCarloPi.chpl_cleanup()
