#include "lib/MonteCarloPi.h"

int main(int argc, char** argv) {
  chpl_library_init(argc, argv);
  chpl__init_MonteCarloPi(1, 2);

  int64_t n = 100000;
  int64_t seed = 589494289;
  serialVersion(n, seed);
  taskParVersion(n, seed);
  dataParVersion(n, seed);

  chpl_library_finalize();

  return 0;
}

